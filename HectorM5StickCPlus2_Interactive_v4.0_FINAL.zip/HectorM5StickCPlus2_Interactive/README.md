# Hector Interactive v4.0 - M5StickC Plus2

## 🎨 Complete Interactive Mathematical Visualization System

Transform your M5StickC Plus2 into a **professional mathematical art masterpiece** with real-time interactivity!

### ✨ **What It Does**
Creates stunning 3D mathematical surface visualizations that respond to:
- **Device movement** (6-axis IMU: tilt, rotation, acceleration) 
- **Sound/music** (I2S digital microphone with professional audio processing)
- **10 different interactive modes** (mathematical algorithms and patterns)
- **4 display styles** (wireframe, solid, striped, checkboard)

### 🎮 **10 Interactive Modes**

| Mode | Description | Experience |
|------|-------------|------------|
| **FLAT** | Perfect baseline grid | Static reference surface |
| **TILT** | Motion reactive | Move device to control surface shape |
| **SOUND** | Audio visualization | Speak, clap, play music - watch it dance! |
| **SPIRAL** | Rotating spirals | Hypnotic mathematical spiral patterns |
| **INTERFERENCE** | Wave interference | Multiple sources creating complex patterns |
| **MOUNTAIN** | Landscape terrain | Dynamic mountain range generation |
| **RIPPLE** | Multi-ripple tank | Multiple water droplet sources |
| **PLASMA** | Energy field | Flowing plasma-like energy visualization |
| **SINE** | Classic sine waves | Pure mathematical sine wave beauty |
| **DRIP** | Water droplets | Organic water ripple simulation |

### 🎛️ **Simple Controls**
- **Button A**: Cycle display styles (Grid → Solid → Zebra → Checkboard)
- **Button B**: Cycle interactive modes (10 modes in sequence)
- **Current mode** shown in top-right corner with real-time indicators

### 📱 **4 Display Rendering Styles**
- **GRID**: Classic wireframe mesh lines
- **SOLID**: Filled 3D surface triangles with depth
- **ZEBRA**: Alternating stripe patterns  
- **CHECKBOARD**: Dotted square grid patterns

### 🔥 **Advanced Features**
- ✅ **Professional I2S Audio**: Real digital microphone processing (44.1kHz, 16-bit)
- ✅ **Real-time IMU Integration**: 6-axis motion sensing (MPU6886)
- ✅ **Advanced Math Engine**: Multiple wave equations and 3D projection
- ✅ **Optimized Performance**: Smooth 30-60fps with efficient memory usage
- ✅ **Visual Debugging**: Audio levels, FPS counter, mode indicators
- ✅ **Landscape Optimized**: Perfect for M5StickC Plus2's 135×240 display

### 🎯 **Perfect For**
- **Digital art installations** and displays
- **Music visualization** and audio-reactive art
- **Mathematical education** and demonstration
- **Interactive presentations** and demos
- **Personal entertainment** and visual relaxation
- **STEM education** showing real-time math concepts

### 📊 **Technical Excellence**
- **Platform**: M5StickC Plus2 (ESP32-PICO-V3-02)
- **Display**: 135×240 landscape TFT optimized
- **Audio**: I2S digital PDM microphone (professional quality)
- **Motion**: MPU6886 6-axis IMU with real-time processing
- **Performance**: 35.6% Flash, 9.4% RAM, 30-60 FPS
- **Math**: Real-time 3D projection with multiple algorithms

### 🚀 **40 Total Experiences**
**10 Interactive Modes** × **4 Display Styles** = **40 unique visual combinations!**

Each combination offers a completely different mathematical and artistic experience.

---

## 🎵 **Audio Features**
The SOUND mode uses professional I2S digital audio processing:
- **RMS Power Analysis**: True audio energy measurement
- **DC Offset Removal**: Clean signal processing  
- **Noise Gate**: Ignores background noise
- **Real-time Response**: <50ms audio latency
- **Visual Feedback**: Shows audio level and power on screen

Try speaking, clapping, playing music, or any audio input - watch the mathematical surface come alive!

---

**Based on ESP32-Hector by tobozo** | **Enhanced for M5StickC Plus2 by Assistant**

*This version exceeds the original in features, performance, and interactivity while maintaining the mathematical beauty that made ESP32-Hector famous.*